package com.idaholottery.rafflesiteproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RaffleSiteProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(RaffleSiteProjectApplication.class, args);
	}

}
